<?php
session_start();
    // session_start();
    // if(!isset($_SESSION['costumer'])){
    //     header("Location: login.php");
    // }
    include 'koneksi.php';
    $id_user = $_SESSION['id_user'];

    $result = mysqli_query($conn, "SELECT * FROM transaksi WHERE id_costumer = $id_user AND konfirmasi_pembayaran = 1");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    
    <title>Document</title>

    <style>
        body{
            margin: 0;
            padding: 0;
            background-color: #eaeaea;
            font-family: "Roboto";
        }
        .navbar{
            width: 100%;
            height: 100px;
            background-color: #FF9900;
            border-radius: 0 0 15px 15px;
            display: flex;
            align-items: center;
        }
        h2{
            display: inline-block;
            color: white;
            padding-left: 20px;
        }
        .menu-item{
            width: 100%;
            height: 200px;
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        .card{
            width: 95%;
            height: 200px;
            background-color: white;
            border-radius: 20px;
            display: flex;
        }
        .img{
            width: 45%;
            height: 200px;
            border-radius: 20px;
            overflow: hidden;
            
        }
        .text{
            width: 55%;
            height: 200px;
            border-radius: 20px;
            padding: 10px;

        }
        .card img{
            width: 300px;
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            <h2>History Transaksi</h2>
        </div>
    </header>
    <?php while($data = mysqli_fetch_assoc($result)) : ?>
    <div class="menu-item">
        <div class="card">
            <div class="img">
                <img src="assets/img/<?=$data['gambar_produk']?>" alt="">
            </div>
            <div class="text">
                <h3><?=$data['nama_produk']?></h3>
            </div>
        </div>
    </div>
    <?php endwhile; ?>
    <p></p>
</body>
</html>