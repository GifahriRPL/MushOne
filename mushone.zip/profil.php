<?php
session_start();
include 'koneksi.php';
if(!isset($_SESSION['costumer'])){
    header("Location: login.php");
}
$nama = $_SESSION['costumer'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
</head>
<style>
    body{
    margin: 0;
    padding: 0;
    background-color: #eaeaea;
    font-family: "Roboto";
}
header{
    width: 100%;
    height: 100px;
    background-color: white;
}
.navbar{
    width: 100%;
    height: 100px;
    background-color: #FF9900;
    border-radius: 0 0 15px 15px;
    display: flex;
    align-items: center;
}
.navbar h2{
    margin-left: 30px;
    color: white;
    text-shadow: 0px .5px .5px rgb(0, 0, 0, 0.3);

}
.menu{
    width: 100%;
    height: 50px;
    background-color: white;
    display: flex;
    align-items: center;
    margin-top: 3px;
}
.menu p{
    margin-left: 30px;
    text-shadow: 0px .5px .5px rgb(0, 0, 0, 0.3);
}
footer{
    margin-top: 3px;
    width: 100%;
    height: 60vh;
    background-color: white;
}
a{
    text-decoration: none;
    color: black;
}
.wrap{
    width: 100%;
    height: 50px;
}
</style>
<body>
    <header>
    <div class="navbar">
        <h2><?=$nama?></h2>
    </div>
    </header>
    <div class="menu">
        <a href="alamat.php">
            <div class="wrap">
       <p>Ganti Alamat</p>
    </a>
</div>
    </div>
    <div class="menu">
        <a href="info-pesanan.php">
            <div class="wrap">
       <p>Pesanan</p>
    </a>
</div>
    </div>
    <div class="menu">
        <a href="">
            <div class="wrap">
       <p>Bantuan</p>
       </a>
       </div>
    </div>
    <div class="menu">
        <a href="">
            <div class="wrap">
         <p>Bahasa</p>
        </a>
    </div>
    </div>
    <div class="menu">
        <a href="">
            <div class="wrap">
           <p>Contact Us</p>
       </a>
       </div>
    </div>
    <div class="menu">
        <a href="logout.php">
            <div class="wrap">
           <p>Log Out</p>
       </a>
       </div>
    </div>
    <footer>

    </footer>
</body>
</html>