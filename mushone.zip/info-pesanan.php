<?php
session_start();
include 'koneksi.php';
if(!isset($_SESSION['costumer'])){
    header("Location: login.php");
}
    $id_user = $_SESSION['id_user'];

    $sql = mysqli_query($conn, "SELECT * FROM transaksi WHERE id_costumer  = $id_user AND status_pesanan = 0 OR status_pesanan = 1");
    $count_1 = mysqli_query($conn, "SELECT COUNT(id_costumer) AS jumlah_dikemas FROM transaksi WHERE id_costumer  = $id_user AND status_pesanan = 0 OR status_pesanan = 1");
    $count_2 = mysqli_query($conn, "SELECT COUNT(id_costumer) AS jumlah_dikirim FROM transaksi WHERE id_costumer  = $id_user AND status_pesanan = 2");
    $count_3 = mysqli_query($conn, "SELECT COUNT(id_costumer) AS jumlah_selesai FROM transaksi WHERE id_costumer  = $id_user AND status_pesanan = 3");
    $data_1 = mysqli_fetch_assoc($count_1);
    $jumlah_dikemas = $data_1['jumlah_dikemas'];
    $data_2 = mysqli_fetch_assoc($count_2);
    $jumlah_dikirim = $data_2['jumlah_dikirim'];
    $data_3 = mysqli_fetch_assoc($count_3);
    $jumlah_selesai = $data_3['jumlah_selesai'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
        body{
            margin: 0;
            padding: 0;
            background-color: #eaeaea;
            font-family: "Roboto";
        }
        .navbar{
            width: 100%;
            height: 100px;
            background-color: #FF9900;
            border-radius: 0 0 15px 15px;
            display: flex;
            align-items: center;
        }
        h2{
            display: inline-block;
            color: white;
            padding-left: 20px;
        }
        .float-button{
            width: 100%;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .wrap{
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 10px;
            margin-top: -3px;

        }
        button{
            width: 90px;
            height: 30px;
            outline: none;
            border: 1px solid #a9a9a3;
            border-radius: 15px;
        }
        span{
            margin: 0;
            padding: 0;
            position: absolute;
            right: 10px;
            top: -10px;
            background-color: rgb(242, 100, 5);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 12px;
        }
        .b1, .b2, .b3{
            width: 33.33%;
            position: relative;
        }

        a{
            color: black;
            text-decoration: none;
        }
        .active{
            background-color: #c6c6c6;
        }
        .menu-item{
            width: 100%;
            height: 150px;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 20px;
            margin-bottom: 10px;
        }
        .card{
            display: flex;
            width: 100%;
            padding: 10px;
            height: 150px;
        }
        .gambar{
            width: 40%;
            height: 150px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .gambar img{
            width: 100px;
        }
        .kanan{
            width: 60%;
            height: 150px;
        }
        .atas{
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
        }
        h5{
            display: inline-block;
        }
        .bawah{
            width: 100%;
            height: 50px;
        }
        .bawah .status{
            display: flex;
            align-items: center;
            width: 100%;
        }
        .jumlah{
            width: 40%;
        }
        .proses{

            width: 60%;
        }
        .status .teks-proses{
            font-style: italic;
            color: green;
            text-align: center;

        }
        .status .teks-jumlah{
            text-align: center;
        }
 
</style>
<body>
    <header>
        <div class="navbar">
            <h2>Pesanan Saya</h2>
        </div>
    </header>
    <div class="float-button">
        <div class="b1">
            <?php 
                if($jumlah_dikemas > 0)
                :
            ?>
            <span>
            <?=$jumlah_dikemas?>
            </span>
            <?php endif?>
            <div class="wrap">
                <button class="active"><a href="info-pesanan.php">Di Kemas</a></button>
            </div>
        </div>
        <div class="b2">
        <?php 
                if($jumlah_dikirim > 0)
                :
            ?>
            <span>
            <?=$jumlah_dikirim?>
            </span>
            <?php endif?>
            <div class="wrap">
            <button><a href="di-kirim.php">Di Kirim</a></button>
        </div>
        </div>
        <div class="b3">
        <?php 
                if($jumlah_selesai > 0)
                :
            ?>
            <span>
            <?=$jumlah_selesai?>
            </span>
            <?php endif?>
            <div class="wrap">
            <button><a href="selesai.php">Selesai</a></button>
        </div>
        </div>
    </div>
    <?php
    while($data = mysqli_fetch_assoc($sql)):
    ?>
    <div class="menu-item">
        <div class="card">
            <div class="gambar">
                <img src="assets/img/<?=$data['gambar_produk']?>" alt="">
            </div>
            <div class="kanan">
                <div class="atas">
                    <div class="teks">
                    <h5><?=$data['nama_produk']?></h5>
                    <h5><?=$data['harga_produk']?></h5>
                </div>
                </div>
                <div class="bawah">
                    <div class="status">
                        <div class="jumlah">
                          <p class="teks-jumlah">jumlah <?=$data['jumlah_produk']?></p>
                        </div>
                        <div class="proses">
                          <p class="teks-proses">Di Kemas</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endwhile?>
</body>
</html>