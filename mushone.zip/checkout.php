<?php
session_start();
include 'koneksi.php';
if(!isset($_SESSION['costumer'])){
    header("Location: login.php");
}

    if(isset($_GET['id_produk'])){
    $jumlah = $_GET['jumlah'];
    $id_produk = $_GET['id_produk'];
    $id_user = $_SESSION['id_user'];
    $costumer = $_SESSION['costumer'];
    
    $query_alamat = mysqli_query($conn, "SELECT * FROM user WHERE id = $id_user");
    $q = mysqli_fetch_assoc($query_alamat);
    $alamat = $q['alamat'];

    $result = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk = $id_produk");
    $data = mysqli_fetch_assoc($result);
    
    $gambar_produk = $data['gambar_produk'];
    $nama_produk = $data['nama_produk'];
    $harga_produk = $data['harga_produk'];
    $subtotal_pesanan = $harga_produk*$jumlah;
    $total = $subtotal_pesanan + 10000 + 2000;
    } else{
        header("Location: index.php");
    }

    // Logika pembayaran
    if(isset($_POST['submit'])){
    
    $query = mysqli_query($conn, "INSERT INTO transaksi VALUES('', '$id_produk', '$id_user', '$costumer', '$nama_produk', '$alamat', '$gambar_produk', '$jumlah', '$harga_produk', '$subtotal_pesanan', '10000', '2000', '$total','')");
    header("Location: index.php");

    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    </head>
    <style>
        header{
            width: 100%;
            height: 80px;
            background-color: white;

        }
        body{
            background-color: #eaeaea;
            margin: 0;
            padding: 0;
            font-family: "Roboto";
        }
        h2{
            display: inline-block;
            margin-left: 20px;
        }
        .wrap{
            margin-top: 5px;
            width: 100%;
            
        }
        .alamat{
            padding: 20px;
            background-color: rgb(255, 255, 255);
            height: 200px;
        }
        .alamat p{
            font-size: 12px;
        }
        h4{
            display: inline-block;
        }
        .wrap-menit{
            width: 100%;
            height: 50px;
            display: flex;
            justify-content: center;
            background-color: white;
        }
        .menit{
            display: flex;
            align-items: center;
            width: 90%;
            height: 35px;
            background-color: #ffaa2b;
            border: 1px solid #bd760c;

        }
        .menit h5{
            color: #5f3c06;
            margin-left: 50px;
        }
        .menu-item{
            width: 100%;
            height: 150px;
            margin-top: 5px;
            background-color: white;
            display: flex;
            overflow: hidden;
        }
        .img{
            width: 40%;
            height: 100px;
            /* background-color: rebeccapurple; */
            padding: 10px;
            overflow: hidden;
        }

        .kanan{
            width: 60%;
            height: 200px;
        }
        .img img{
            width: 200px;
        }
        .kanan h4{
            position: absolute;
            right: 0;
            margin-top: -20px;
            margin-right: 20px;
        }
        .capt{
            padding: 10px;
            
        }
       
        .subtotal{
            width: 100%;
            height: 120px;
            background-color: white;
            margin-top: 5px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        .teks{
            width: 70%;
            padding: 20px;
            /* background-color: rebeccapurple; */
        }
        .rp{
            width: 30%;
            text-align: center;
            /* margin-left: 130px; */
            padding: 20px;
        }
        .total{
            width: 100%;
            height: 50px;
            background-color: white;
            margin-top: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .kiri{
            width: 70%;
            /* margin-left: 30px; */
            padding-left: 20px;
        }
        .total-harga{
            width: 30%;
        }
        .footer{
            width: 100%;
            height: 150px;
            background-color: white;
            margin-top: 5px;
            display: flex;
            justify-content: center;
        }
        .footer button{
            margin-top: 35px;
            width: 200px;
            height: 40px;
            outline: none;
            border: none;
            background-color: #f3960a;
        }
        
        
    </style>
<body>
    <header>
        <h2>Check Out</h2>
    </header>
    <div class="wrap">
    <div class="alamat">
        <h4>Alamat Pengiriman</h4>
        <?php
        if($alamat == NULL):
        ?>
        <p>Atur alamat <a href="alamat.php">Di sini</a></p>
        <?php endif?>
        <p><?=$alamat?></p>
    </div>
    <div class="wrap-menit">
        <div class="menit">
            <h5>Standar - 40 menit</h5>
        </div>
    </div>
</div>
    <div class="menu-item">
        <div class="img">
            <img src="assets/img/<?=$data['gambar_produk']?>" alt="">
        </div>
        <div class="kanan">
            <div class="capt">
            <h5>MushOne Original</h5>
            <h5>Rp <?=$harga_produk?></h5>
            <h4>Jumlah <?=$jumlah?></h4>
        </div>
        </div>
    </div>
    <div class="subtotal">
        <div class="teks">
            <p>Subtotal Pesanan</p>
            <p>Biaya Pengiriman</p>
            <p>Biaya Layanan</p>
        </div>
        <div class="rp">
            <P>Rp <?=$subtotal_pesanan?></P>
            <P>Rp 10.000</P>
            <P>Rp 2.000</P>
        </div>
    </div>
    <div class="total">
        <div class="kiri">
            <h4>Total</h4>
        </div>
        <div class="total-harga">
            <h4>Rp <?=$total?></h4>
        </div>
    </div>
    <div class="footer">
        <form method="post" action="">
            <button name="submit" type="submit">Pesan Sekarang</button>
        </form>
    </div>
</body>
</html>