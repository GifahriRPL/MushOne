<?php 
    include "koneksi.php";
    $id_produk = $_GET['id'];
    $query = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk = $id_produk");
    $data = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
</head>
    <style>
        body{
            margin: 0;
            padding: 0;
            background-color: #eaeaea;
            height: 100vh;
            font-family: "Roboto";
        }
        header{
            width: 100%;
            height: 240px;
            overflow: hidden;
        }
        img{
            width: 500px;
        }
        .card{
            width: 100%;
            background-color: white;
            border-radius: 10px 10px 0 0;
            margin-top: -15px;
            position: relative;
            display: flex;
        }
        h2{
            display: inline-block;
        }
        .content-item{
            width: 50%;
            padding-left: 30px;
            padding-top: 20px;
            
        }

        .harga{
            width: 50%;
            padding-left: 35px;
            padding-top: 20px;
            text-align: center;
        }
        .harga h2{
            color: #FF9900;
            text-shadow: 0px .5px .5px rgb(0, 0, 0, 0.3);
        }
        .caption{
            width: 100%;
            height: 100px;
            background-color: white;
            /* padding-left: 30px; */
        }
        .caption h6{
            display: inline-block;
            font-size: 14px;
            color: rgb(18, 17, 17);
        }
        .catatan{
            width: 100%;
            height: 100px;
            background-color: white;
            margin-top: 10px;
            /* padding-left: 30px; */
        }
        .capt{
            padding: 0 20px;
        }
        .catatan h5{
            margin-top: -17px;
        }
        .card-input{
            width: 100%;
            height: 50px;
            background-color: white;
            margin-top: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card-input input{
            width: 80%;
            height: 30px;
            outline: none;
            border: none;
        }
        footer{
            margin-top: 5px;
            width: 100%;
            height: 27vh;
            background-color: white;
            /* display: flex;
            justify-content: center; */
        }
        footer input{
            width: 10%;
            height: 30px;
            background-color: none;
        }

        .count{
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;

        }

        .checkout{
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .checkout button{
            width: 200px;
            height: 40px;
            outline: none;
            border: none;
            background-color: #FF9900;
        }
        .checkout p {
            font-weight: 700;
        }
    </style>
    <body>
        <header>
            <img src="assets/img/<?=$data['gambar_produk']?>" alt="">
        </header>
        <div class="row">
        <div class="card">
            <div class="content-item">
                <h2><?=$data['nama_produk']?></h2>
            </div>
            <div class="harga">
                <h2><b>Rp 5.000</b></h2>
            </div>
        </div>
        <div class="caption">
            <div class="capt">
            <h6><?=$data['deskripsi_produk']?></h6>
        </div>
        </div>
    </div>
    <!-- Catatan -->
    <div class="catatan">
        <div class="capt">
        <h2>Catatan Untuk Restoran</h2>
        <h5>(Tidak Wajib)</h5>
    </div>
    </div>
    <!-- Inpur -->
    <form method="get" action="checkout.php">
    <div class="card-input">
        <input name="catatan" type="text" placeholder=" Masukan catatan disini" value="">
        <input name="id_produk" type="hidden" value="<?=$data['id_produk']?>">
    </div>
    <footer>
        <div class="wrap-count">
        <div class="count">
            <input required name="jumlah" min="1" type="number">
        </div>
    </div>
        <div class="checkout">
                <button type="submit">Check Out</button>
            </form>
        </div>
    </footer>
    </body>
    </html>
</body>
</html>