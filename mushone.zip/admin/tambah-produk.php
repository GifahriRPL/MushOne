<?php
    include '../koneksi.php';
    if(isset($_POST['submit'])){
        $produk = $_POST['produk'];
        $harga = $_POST['harga'];
        $stok = $_POST['stok'];
        $deskripsi = $_POST['deskripsi'];

        $query = mysqli_query($conn, "INSERT INTO produk VALUES('', '$produk', '$harga', '$deskripsi', '$stok','')");
        header("Location: stok-produk.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Produk</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
.navbar{
        width: 100%;
        height: 100px;
        background-color: #FF9900;
    }
    .konten{
      display: flex;
    }
    .containert{
      width: 90%;
      padding-right: 5%;
    }
    .sidebar{
      width: 10%;
      height: 80vh;
      /* background-color: #eaeaea; */
      box-shadow: 1px 1px 1px 1px rgb(217, 212, 212, 0.5);
      margin-right: 5%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .wrap-logo{
      width: 100%;
      height: 400px;
      /* background-color: rebeccapurple; */
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .logo{
      width: 80%;
      height: 100px;
      background-color: #FF9900;

      display: flex;
      align-items: center;
      justify-content: center;
      position: sticky;
      border-radius: 5px;
      margin-bottom: 5px;
    }
    a{
        color: black;
    }
  </style>
</head>
<body>
<div class="navbar"></div>
<div class="konten">

<div class="sidebar">
      <div class="wrap-logo">
        <div class="logo">
          <a href="index.php">
          <i class="fas fa-list fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="stok-produk.php">
          <i class="fas fa-shopping-cart fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="user.php">
          <i class="fas fa-user fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="riwayat-transaksi.php">
          <i class="fas fa-undo-alt fa-2x"></i>
          </a>
        </div>
        </div>
    </div>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Tambah Data Produk
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="nama_produk" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="nama_produk" name="produk" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="number" class="form-control" id="harga" name="harga" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Stok</label>
                            <input type="number" class="form-control" id="harga" name="stok" required>
                        </div>
                        <div class="mb-3">
                            <label for="deskripsi" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
                        </div>
               
                        <button name="submit" type="submit" class="btn btn-primary">Tambah Produk</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
