<?php

        include '../koneksi.php';
        $result = mysqli_query($conn, "SELECT * FROM user");

        // if(isset)

?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Menggunakan Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <title>Halaman Admin</title>
  <style>
    .navbar{
        width: 100%;
        height: 100px;
        background-color: #FF9900;
    }
    .konten{
      display: flex;
    }
    .containert{
      width: 90%;
      padding-right: 5%;
    }
    .sidebar{
      width: 10%;
      height: 80vh;
      /* background-color: #eaeaea; */
      box-shadow: 1px 1px 1px 1px rgb(217, 212, 212, 0.5);
      margin-right: 5%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .wrap-logo{
      width: 100%;
      height: 400px;
      /* background-color: rebeccapurple; */
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .logo{
      width: 80%;
      height: 100px;
      background-color: #FF9900;

      display: flex;
      align-items: center;
      justify-content: center;
      position: sticky;
      border-radius: 5px;
      margin-bottom: 5px;
    }
    a{
      color: black;
    }
  </style>
</head>
<body>

    <div class="navbar">
        
    </div>
    <div class="konten">

    <div class="sidebar">
      <div class="wrap-logo">
        <div class="logo">
          <a href="index.php">
          <i class="fas fa-list fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="stok-produk.php">
          <i class="fas fa-shopping-cart fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="user.php">
          <i class="fas fa-user fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="riwayat-transaksi.php">
          <i class="fas fa-undo-alt fa-2x"></i>
          </a>
        </div>
        </div>
    </div>


    <div class="containert mt-5">
    <h2>Pengguna</h2>

    <table class="table table-striped mt-3">
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Username</th>
          <th scope="col">Password</th>
          <th scope="col">Email</th>
          <th scope="col">Role</th>
          <th scope="col">Alamat</th>
          <th scope="col">Hapus</th>
          
        </tr>
      </thead>
      <tbody>
      <?php $no = 1;?>
            <?php while( 
             $data = mysqli_fetch_assoc($result)

            ) : ?>
        <tr>
            <td><?=$no++?></td>
            <td><?=$data['username']?></td>
            <td><?=$data['password']?></td>
            <td><?=$data['email']?></td>
            <td><?=$data['role']?></td>
            <td><?=$data['alamat']?></td>
            <td>
                <form action="" method="post">
            <a href="hapus-user.php?id=<?=$data['id']?>" class="btn btn-danger">Hapus</a>
            </form>
            </td>
        </tr>
        <?php endwhile;?>
      </tbody>
    </table>
  </div>
  </div>
  <!-- Menggunakan Bootstrap JS (dan Popper.js) untuk beberapa fitur -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

        