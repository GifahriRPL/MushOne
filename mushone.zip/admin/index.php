<?php
    session_start();
    if(!isset($_SESSION['admin'])){
        header("Location: ../login.php");
    }

    include '../koneksi.php';

    $result = mysqli_query($conn, "SELECT * FROM transaksi WHERE status_pesanan != 3");

    if(isset($_POST["konfirmasi"])){
        $konfirmasi = $_POST['konfirmasi'];
        mysqli_query($conn, "UPDATE transaksi SET status_pesanan = 1  WHERE id_transaksi=$konfirmasi");

    }
    
    if(isset($_POST["kirim"])){
        $konfirmasi = $_POST['kirim'];
        mysqli_query($conn, "UPDATE transaksi SET status_pesanan = 2  WHERE id_transaksi=$konfirmasi");
    }
    if(isset($_POST["selesai"])){
       $id_produk = $_POST['id_produk'];
        $konfirmasi = $_POST['selesai'];
        mysqli_query($conn, "UPDATE produk SET stok = stok -1 WHERE id_produk = $id_produk");
        mysqli_query($conn, "UPDATE transaksi SET status_pesanan = 3  WHERE id_transaksi=$konfirmasi");
    }
    

?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Menggunakan Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <title>Halaman Admin</title>
  <style>
    .navbar{
        width: 100%;
        height: 100px;
        background-color: #FF9900;
    }
    .konten{
      display: flex;
    }
    .containert{
      width: 90%;
      padding-right: 5%;
    }
    .sidebar{
      width: 10%;
      height: 80vh;
      /* background-color: #eaeaea; */
      box-shadow: 1px 1px 1px 1px rgb(217, 212, 212, 0.5);
      margin-right: 5%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .wrap-logo{
      width: 100%;
      height: 450px;
      /* background-color: rebeccapurple; */
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .logo{
      width: 80%;
      height: 100px;
      background-color: #FF9900;

      display: flex;
      align-items: center;
      justify-content: center;
      position: sticky;
      border-radius: 5px;
      margin-bottom: 10px;
    }
    a{
      color: black;
    }
    .d{
      font-size: 45px;
    }
  </style>
</head>
<body>

    <div class="navbar">
        
    </div>
    <div class="konten">

    <div class="sidebar">
      <div class="wrap-logo">
        <div class="logo">
          <a href="index.php">
          <i class="fas fa-list fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="stok-produk.php">
          <i class="fas fa-shopping-cart fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="user.php">
          <i class="fas fa-user fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="riwayat-transaksi.php">
          <i class="fas fa-undo-alt fa-2x"></i>
          </a>
        </div>
        <div class="logo">
          <a href="keuangan.php">
          <i class="d fas fa-dollar-sign fa-2x"></i>
          </a>
        </div>
        </div>
    </div>


    <div class="containert mt-5">
    <h2>Dashboard Admin</h2>

    <table class="table table-striped mt-3">
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Pemesan</th>
          <th scope="col">Alamat</th>
          <th scope="col">Produk</th>
          <th scope="col">Harga</th>
          <th scope="col">Jumlah</th>
          <th scope="col">Ongkos Kirim</th>
          <th scope="col">Biaya Layanan</th>
          <th scope="col">Total</th>
          <th scope="col">Konfirmasi</th>
          <th scope="col">Kirim</th>
        </tr>
      </thead>
      <tbody>
        <!-- Data tabel akan diisi melalui backend -->
        <?php $no = 1;?>
            <?php while( 
             $data = mysqli_fetch_assoc($result)

            ) : ?>
        <tr>
          <th scope="row"><?=$no++?></th>
          <td><?=$data['nama_costumer']?></td>
          <td><?=$data['alamat']?></td>
          <td><?=$data['nama_produk']?></td>
          <td><?=$data['harga_produk']?></td>
          <td><?=$data['jumlah_produk']?></td>
          <td><?=$data['ongkos_kirim']?></td>
          <td><?=$data['biaya_layanan']?></td>
          <td><?=$data['total_produk']?></td>
          
          <td>
                <?php if($data['status_pesanan'] == 0){ ?>
                        <form action="" method="post">
                            <button type="submit" value="<?=$data['id_transaksi']?>" name="konfirmasi" class="btn btn-success">Konfirmasi</button>
                        </form>
                    <?php }?>
                </td>
          <td>
                <?php if($data['status_pesanan'] == 1){ ?>
                        <form action="" method="post">
                            <button type="submit" value="<?=$data['id_transaksi']?>" name="kirim" class="btn btn-success">Kirim Sekarang</button>
                        </form>
                    <?php }?>
                <?php if($data['status_pesanan'] == 2){ ?>
                        <form action="" method="post">
                        <input name="id_produk" type="hidden" value="<?=$data['id_produk']?>">
                            <center><button type="submit" value="<?=$data['id_transaksi']?>" name="selesai" class="btn btn-danger">Selesai</button></center>
                        </form>
                    <?php }?>
                </td>
        </tr>
        <?php endwhile ?>
        <!-- Data lainnya -->
      </tbody>
    </table>
  </div>
  </div>
  <!-- Menggunakan Bootstrap JS (dan Popper.js) untuk beberapa fitur -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>
