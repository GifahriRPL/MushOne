<?php
        include '../koneksi.php';

        $result = mysqli_query($conn, "SELECT * FROM transaksi WHERE id_produk = 2");
        $count_1 = mysqli_query($conn, "SELECT SUM(jumlah_produk) AS jumlah_a FROM transaksi WHERE status_pesanan = 3 AND id_produk = 1");
        $count_2 = mysqli_query($conn, "SELECT SUM(jumlah_produk) AS jumlah_b FROM transaksi WHERE status_pesanan = 3 AND id_produk = 2");
        $count_3 = mysqli_query($conn, "SELECT SUM(jumlah_produk) AS jumlah_c FROM transaksi WHERE status_pesanan = 3 AND id_produk = 3");
        $a = mysqli_fetch_assoc($count_1);
        $b = mysqli_fetch_assoc($count_2);
        $c = mysqli_fetch_assoc($count_3);
        
        $x = 5000 * $a['jumlah_a'];
        $y = 5000 * $b['jumlah_b'];
        $z = 5000 * $c['jumlah_c'];
        $total = $x+$y+$z;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tabel Keuangan Penjualan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
.container {
    width: 30%; /* Lebar tabel */
    margin: 0 auto; /* Posisi di tengah */
}
.table {
    font-size: 0.8em; /* Ukuran font tabel diperkecil */
}
td {
    width: 50px ;
    overflow: hidden;
    text-overflow: ellipsis; /* Tampilkan titik elipsis untuk teks yang terpotong */
    white-space: nowrap; /* Agar teks tidak wrap */
}
</style>
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Tabel Keuangan Penjualan</h2>
    <table class="table table-bordered text-center">
        <thead>
            <tr>
                <th>Produk</th>
                <th>Harga</th>
                <th>Terjual</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>MushOne Pedas</td>
                <td>5000</td>
                <td><?=$a['jumlah_a']?></td>
                <td><?=$x?></td>
            </tr>
            <tr>
                <td>MushOne Original</td>
                <td>5000</td>
                <td><?=$b['jumlah_b']?></td>
                <td><?=$y?></td>
            </tr>
            <tr>
                <td>MushOne Asin</td>
                <td>5000</td>
                <td><?=$c['jumlah_c']?></td>
                <td><?=$z?></td>
            </tr>
            <tr>
                <td colspan="3"><strong>Omset</strong></td>
                <td><strong><?=$total?></strong></td>
            </tr>
        </tbody>
    </table>
</div>
</body>
</html>
