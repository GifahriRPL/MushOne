<?php
    include 'koneksi.php';

    if(isset($_POST['submit'])){
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $email = $_POST['email'];
        $query = mysqli_query($conn, "INSERT INTO user VALUES('', '$user', '$pass', '$email', '', 'user')");
        header("Location: login.php");
    }

?>

<!DOCTYPE html>
<html lang="id">
<head>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
</head>
  <title>Halaman Login</title>
  <style>
    body{
      font-family: "Roboto";
      margin: 0;
      padding: 0;
      width: 100%;
    }
    .container{
      width: 100%;
      height: 100vh;
      background-image: url('assets/img/background.png');
      background-repeat: no-repeat;
    }
    .teks{
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 200px;
    }
    .teks h1{
      display: inline-block;
    }
    .teks h4{
      margin-top: -17px;
      display: inline-block;
    }
    .form-area{
      display: flex;
      z-index: 2;
      justify-content: center;
      width: 100%;
      margin-top: -40px;
    }
    .kotak{
      width: 97%;
      height: 350px;
      background-color: rgb(22, 22, 22, 0.85);
      border-radius: 30px;
      margin: auto;
    }
    .form-group{
      width: 100%;
      height: 40px;
      margin-top: 30px;

    }
    .wrap{
      width: 100%;
      display: flex;
      justify-content: center;
    }
    .form-group input{
      width: 100%;
      height: 45px;
      outline: none;
      border: none;
      padding-left: 25px;
      border-radius: 30px;
      z-index: 99;
      font-size: 18px;
    }
    .forget{
      display: flex;
      justify-content: center;
      width: 100%;
    }
    .wrap-forget{
      width: 97%;

    }
    .forget p{
      display: inline-block;
      color: white;
      font-size: 12px;
      padding: 15px;
      margin-left: 35px;
      
    }
    .ruang-button{
      width: 100%;
      display: flex;
      justify-content: center;
      margin-top: 30px;

    }
    .wrap-button{
      width: 97%;
      height: 60px;
      margin-top: -1;
      display: flex;
      justify-content: center;
      transition: .5s;
    }
    button{
      width: 70%;
      height: 45px;
      outline: none;
      border: none;
      border-radius: 30px;
      background-color: rgb(226, 226, 226, 0.4px);
    }
    button:hover{
      background-color: #FF9900;
    }
    .signup{
      width: 100%;
      display: flex;
      justify-content: center;
      height: 50px;
      
    }
    .signup p{
      font-size: 14px;
      color: white;
    }
    .or{
      width: 100%;
      height: 50px;
      display: flex;
      justify-content: center;
      margin-top: 20px;
    }
    .wrap-or{
      width: 97%;
      height: 150px;
      border-radius: 30px;
      background-color: rgb(22, 22, 22, 0.85);

    }
    .or-acc{
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .logo{
      width: 30%;
      display: flex;
      align-items: center;
    }
    .logo .fb{
      width: 40px;
      margin-left: 10px;
      color: white;
    }
    .bungkus{
      margin-top: 15px;
      height: 50px;
      width: 80%;
      display: flex;
      justify-content: center;
      border-radius: 25px;
    }
    .bg-go{
      background-color: white;
    }
    .bg-fb{
      background-color: #00488B;
    }
    h2{
      display: inline-block;
      color: white;
      text-align: center;
    }
    .capt{
      display: flex;
      align-items: center;
      justify-content: center;
    }
    a{
      color: white;
      text-decoration: none;
    }
  </style>
</head>
<body>
    <div class="container">
      <div class="teks">
        <h1>Signup</h1>
        <h4>Make Your Account</h4>
      </div>
      <div class="kotak">
      <div class="form-area">
        <form action="" method="post">
        <div class="wrap-form">
          <div class="form-group">
            <div class="wrap">
              <input name="user" placeholder="Username" type="text">
            </div>
          </div>
          <div class="form-group">
            <div class="wrap">
              <input name="email" placeholder="Email" type="text">
            </div>
          </div>
   
          <div class="form-group">
            <div class="wrap">
              <input name="pass" placeholder="Password" type="password">
            </div>
          </div>
        </div>
      </div>
    
      <div class="ruang-button">
        <div class="wrap-button">
          <button name="submit" type="submit">Create Account</button>
        </div>
        </form>
      </div>
      <div class="signup">
      </div>
    </div>
    </div>
</body>
</html>
