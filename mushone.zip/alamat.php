<?php
    session_start();
    include 'koneksi.php';
    if(!isset($_SESSION['costumer'])){
        header("Location: login.php");
    }

    $id_user = $_SESSION['id_user'];
    $sql = mysqli_query($conn, "SELECT * FROM user WHERE id = $id_user");
    $data = mysqli_fetch_assoc($sql);
    if(isset($_POST['submit'])){
        $alamat = $_POST['alamat'];
        $query = mysqli_query($conn, "UPDATE user SET alamat = '$alamat' WHERE id = $id_user");
        header("Location: index.php");
    }



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
body{
    margin: 0;
    padding: 0;
    background-color: #eaeaea;
    font-family: "Roboto";
}
header{
    width: 100%;
    height: 100px;
    background-color: white;
}
.navbar{
    width: 100%;
    height: 100px;
    background-color: #FF9900;
    border-radius: 0 0 15px 15px;
    display: flex;
    align-items: center;
}
.navbar h2{
    margin-left: 24px;
    color: white;
    text-shadow: 0px .5px .5px rgb(0, 0, 0, 0.3);
}
.container{
    width: 100%;
    display: flex;
    justify-content: center;
}
.card{
    width: 90%;
    margin-top: 20px;
    border-radius: 10px;
    height: 200px;
    background-color: white;
    display: flex;
    align-items: center;
    justify-content: center;
}
textarea{
    width: 90%;
    border: none;
    outline: none;
}
.wrap-button{
    width: 90%;
    height: 50px;
    position: relative;
}
button{
    position: absolute;
    margin-top: 15px;
    width: 130px;
    height: 40px;
    outline: none;
    border: none;
    background-color: #FF9900;
    right: 0;
    border-radius: 4px;
}
</style>
<body>
    <div class="navbar">
        <h2>Alamat</h2>
    </div>
    <div class="container">
        <div class="card">
            <form action="" method="post">
            <textarea placeholder="Masukan Alamat" name="alamat" id="" cols="30" rows="10">
            <?=$data['alamat']?>
            </textarea>
        </div>
    </div>
    <div class="wrap-button">
        <button name="submit" type="submit">Simpan</button>
        </form>
    </div>
</body>
</html>