<?php
session_start();
include 'koneksi.php';

    $result = mysqli_query($conn, "SELECT * FROM produk");
    $data = mysqli_fetch_assoc($result);


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <title>Mush One</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Roboto";
            background-color: #eaeaea;
        }
        .navbar{
            width: 100%;
            background-color: #FF9900;
            display: flex;
            justify-content: center;
        }

        .col-1{
            width: 15%;
            height: 50px;
            margin-top: 35px;

        }
        .col-2{
            margin-top: 30px;
            padding-left: 10px;
            padding-right: 10px;
            width: 70%;
            height: 50px;
            /* background-color: rgb(0, 255, 213); */

        }
        .col-3{
            margin-top: 35px;
            width: 15%;
            height: 50px;
            /* background-color: red; */
        }
        input{
            width: 100%;
            height: 40px;
            border: none;
            outline: none;
            border-radius: 6px;
            box-shadow: .7px .7px .5px 1px rgb(0, 0, 0, .3);
        }
        .bar{
            width: 100%;
            height: 200px;
            background-color: #FF9900;
        }
        .menu{
            width: 100%;
            height: 100px;
            border-radius: 20px;
            background-color: #eaeaea;
            margin-top: -15px;
          
        }
        .card-discount{
            width: 100%;
            height: 100px;
            position: absolute;
            margin-top: -75px;
        }
        .card-discount img{
            margin-top: -50px;
            width: 350px;
        }
        h2{
            margin-left: 20px;
        }
        .row{
            width: 100%;
            height: 200px;
            display: flex;
        }
        .card-item{
            width: 45%;
            height: 250px;
            background-color: #ffffff;
            margin-left: 12px;
            border-radius: 10px;
            
        }
        .card-header{
            width: 100%;
            height: 150px;
            border-radius: 10px;
            overflow: hidden;

            
        }
        .card-header img{
            width: 230px;
        }
        .card-produk p{
            margin-top: -10px;
        }
        .card-produk{
            padding: 10px;
        }
        a{
            text-decoration: none;
            color: black;
        }
    </style>
</head>
<body>
    <header>
        <div class="bar-atas">
        <div class="navbar">   
            <div class="col-1">
                <center>
                    <a href="profil.php"><img src="assets/img/info akun.png" alt=""></a>
                </center>
            </div>
            <div class="col-2">
                <input type="text" placeholder="Search here">
            </div>
            <div class="col-3">
                <center>
                    <a href="info-pesanan.php"><img src="assets/img/kramjang.png" alt=""></a>
                </center>
            </div>
        </div>
            <div class="bar">

            </div>
            <div class="card-discount">
                <center>
                    <img src="assets/img/promo card 1.png" alt="">
                </center>
            </div>
            <!-- Menu -->
            <div class="menu">
            </div>
        </div>
        <div class="item">
            <h2>Paling Favorit</h2>
            
            <div class="row">
                <div class="card-item">
                    <a href="detail.php?id=1">
                    <div class="card-header">
                        <img src="assets/img/mushone_original.jpg" alt="">
                    </div>
                    <div class="card-produk">
                        <h4>MushOne Original</h4>
                        <p><b>Rp.5000</b></p>
                    </div>
                </a>
                </div>
                
                <div class="card-item">
                <a href="detail.php?id=2">

                    <div class="card-header">
                        <img src="assets/img/mushone_pedas.jpg" alt="">
                    </div>
                    <div class="card-produk">
                        <h4>MushOne Pedas</h4>
                        <p><b>Rp.5000</b></p>
                    </div>
                </div>
                </a>
            </div>

                <!--Row 2  -->
            <br><br><br><br>
            <div class="row">
                <div class="card-item">
                <a href="detail.php?id=3">
                    <div class="card-header">
                        <img src="assets/img/mushone_asin.jpg" alt="">
                    </div>
                    <div class="card-produk">
                        <h4>MushOne Asin</h4>
                        <p><b>Rp.5000</b></p>
                    </div>
                    </a>
                </div>
                <div class="card-item">
                <a href="detail.php?id=2">
                    <div class="card-header">
                        <img src="assets/img/mushone_original.jpg" alt="">
                        
                    </div>
                    <div class="card-produk">
                        <h4>MushOne Original</h4>
                        <p><b>Rp.5000</b></p>
                    </div>
                    </a>
                </div>
            </div>
        </div>
    </header>
</body>
</html>